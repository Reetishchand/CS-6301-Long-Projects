Long Project 1:

Team Members -
Reetish Chand Guntakal Patil (RXG190006)
Rohan Vannala (RXV190003)
Umar Khalid (UXK150630)
Dhara Patel (DXP190051)

Files included -
1. Num.java
2. TestLP1.java 

Methods implemented -

Num(String s): Constructor class which created the Num object
Num(long s): Constructor class for Num
String toString(): Converting Num class into string
Num add(Num a, Num b): Sum of 'a' and 'b'
Num subtract(Num a, Num b): Difference between 'a' and 'b'
Num product(Num a, Num b): Product of 'a' and 'b'
Num power(Num x, long n): x power n (x^n)
printList(): Print the elements of the list and their corresponding base
Num divide(Num a, Num b): Division a / b
Num mod(Num a, Num b): Remainder after division a / b
Num squareRoot(Num a): Square root of a
Num evaluatePostfix(String[] postFixArr): Evaluating an expression in postfix
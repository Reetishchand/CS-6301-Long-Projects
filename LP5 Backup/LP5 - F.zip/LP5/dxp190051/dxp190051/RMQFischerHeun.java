package dxp190051;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Stack;

public class RMQFischerHeun implements RMQStructure {
    RMQIndexSparseTable rmwSparseTbl;
    int[] blockArray;
    int blockSize;
//    ArrayList<RMQIndexSparseTable> sptArray;
    int[] cartesians;
    int numBlocks;
    HashMap<Integer, RMQIndexSparseTable> cartesianRMQs;

    @Override
    public void preProcess(int[] arr) {
        blockSize = (int)Math.ceil(Math.sqrt(arr.length));
        //System.out.println(blkSize);
        blockArray = new int[blockSize];
        numBlocks = arr.length/blockSize + 1;
        Arrays.fill(blockArray, Integer.MAX_VALUE);

        for(int i = 0; i < arr.length; i++){
            blockArray[i/blockSize] = Math.min(arr[i], blockArray[i/blockSize]);
        }

//        sptArray = new ArrayList<RMQSparseTable>();

        cartesians = new int[numBlocks];
        cartesianRMQs = new HashMap<Integer, RMQIndexSparseTable>();
//        cartesianRMQs = new RMQSparseTable[(int) Math.pow(2, 2*blkSize)];

        for(int i = 0; i < numBlocks ; i++) {

            int last = Math.min((i+1) * blockSize, arr.length);
            int c = CartesianNumber(arr, i * blockSize, last);
            cartesians[i] = c;

            if( cartesianRMQs.get(c) == null) {
                RMQIndexSparseTable spt = new RMQIndexSparseTable();
                int[] part = Arrays.copyOfRange(arr, i * blockSize, (i+1) * blockSize);
                spt.preProcess(part);
                cartesianRMQs.put(c, spt);
            }
        }

        int[] blockMin = blockArray;
        rmwSparseTbl = new RMQIndexSparseTable();
        rmwSparseTbl.preProcess(blockMin);
    }

    @Override
    public int query(int[] arr, int left, int right) {
        int leftBlock = left/blockSize;
        int rightBlock = right/blockSize;
        int min = Integer.MAX_VALUE;

        if(leftBlock == rightBlock){
            for(int i = left; i <= right; i++){
                min = Math.min(min, arr[i]);
            }
            return min;
        }

        //get blocks min except left and right blocks

        if (rightBlock - leftBlock > 1) {
            min = rmwSparseTbl.query(blockArray, leftBlock + 1, rightBlock - 1);
        }

        //get left block min
        int leftC = cartesians[leftBlock];
        RMQIndexSparseTable sptLeft = cartesianRMQs.get(leftC);

        int[] leftpart = Arrays.copyOfRange(arr, leftBlock * blockSize, (leftBlock+1) * blockSize);

        int minLeft =  sptLeft.query(leftpart, left % blockSize, blockSize -1);
        min = Math.min(minLeft, min);


        //get right block min
        int rightC = cartesians[rightBlock];
        RMQIndexSparseTable sptRight = cartesianRMQs.get(rightC);

        int[] rightpart = Arrays.copyOfRange(arr, rightBlock * blockSize, (rightBlock+1) * blockSize);

        int minRight =  sptRight.query(rightpart, 0, right % blockSize);
        min = Math.min(minRight, min);
        return min;
    }

    private int add0right(int x) {
        return 2*x;
    }

    private int add1right(int x) {
        return 2*x + 1;
    }

    private int CartesianNumber(int[] elements, int i, int j) {
        // todo - refactor
        int cartesian = 0;
        Stack<Integer> stack = new Stack<Integer>();
        stack.push(i);
        cartesian = add1right(cartesian);
        // Calculate the cartesian number using stack algorithm. Each is pushed
        // on stack once and popped off once, thus linear time.
        for (int k = i+1; k < j; k++) {
            while (!stack.isEmpty() && elements[k] < elements[stack.peek()]) {
                stack.pop();
                cartesian = add0right(cartesian);
            }
            stack.push(k);
            cartesian = add1right(cartesian);
        }
        while (!stack.isEmpty()) {
            stack.pop();
            cartesian = add0right(cartesian);
        }
        return cartesian;
    }

}

package dxp190051;

import java.util.ArrayList;
import java.util.Arrays;

public class RMQHybridOne implements RMQStructure{
    RMQSparseTable rmwSparseTbl;
    int[] blockArray;
    int blockSize;
    ArrayList<RMQSparseTable> sptArray;

    @Override
    public void preProcess(int[] arr) {
        blockSize = (int)Math.ceil(Math.sqrt(arr.length));
        //System.out.println(blockSize);
        blockArray = new int[blockSize];
        Arrays.fill(blockArray, Integer.MAX_VALUE);

        for(int i = 0; i < arr.length; i++){
            blockArray[i/blockSize] = Math.min(arr[i], blockArray[i/blockSize]);
        }

        sptArray = new ArrayList<RMQSparseTable>();

        for(int i = 0; i < arr.length/blockSize + 1; i++) {
            RMQSparseTable spt = new RMQSparseTable();

            int[] part = Arrays.copyOfRange(arr, i * blockSize, (i+1) * blockSize);
            spt.preProcess(part);
            sptArray.add(spt);
        }

        int[] blockMin = blockArray;
        rmwSparseTbl = new RMQSparseTable();
        rmwSparseTbl.preProcess(blockMin);
    }

    @Override
    public int query(int[] arr, int left, int right) {
        int leftBlock = left/blockSize;
        int rightBlock = right/blockSize;
        int min = Integer.MAX_VALUE;

        if(leftBlock == rightBlock){
            for(int i = left; i <= right; i++){
                min = Math.min(min, arr[i]);
            }
            return min;
        }

        //get blocks min except left and right blocks
        min = rmwSparseTbl.query(blockArray, leftBlock+1, rightBlock-1);

        //get left block min
        RMQSparseTable sptLeft = sptArray.get(leftBlock);

        int minLeft =  sptLeft.query(arr, left % blockSize, blockSize -1);
        min = Math.min(minLeft, min);


        //get right block min
        RMQSparseTable sptRight = sptArray.get(rightBlock);
        int minRight =  sptRight.query(arr, 0, right % blockSize);
        min = Math.min(minRight, min);
        return min;
    }
}

package dxp190051;

public class RMQIndexSparseTable implements RMQStructure{

    int[][] spt;
    @Override
    public void preProcess(int[] arr) {
        int len = arr.length;
        int k = (int) Math.ceil(log2(len)) + 1;
        spt = new int[len][k];

        for (int i = 0; i < len; i++){
            spt[i][0] = i;
        }

        for (int j = 1; Math.pow(2, j) <= len;  j++){
            for (int i = 0; i + Math.pow(2, j) - 1 < len; i++){
                int ind1 = spt[i][j-1];
                int ind2 = spt[i + (int)Math.pow(2, j-1)][j - 1];
                if(arr[ind1] < arr[ind2]) {
                    spt[i][j] = ind1;
                } else {
                    spt[i][j] = ind2;
                }
            }
        }
    }

    private void printSparseTable(){
        for (int i = 0; i < spt.length; i++){
            for (int j = 0; j < spt[0].length; j++){
                System.out.print(spt[i][j] + " ");
            }
            System.out.println();
        }
    }

    @Override
    public int query(int[] arr, int i, int j) {
        int k = (int) Math.floor(log2(j - i + 1));
        int left = spt[i][k];
        int right = spt[j - (int) Math.pow(2, k) + 1][k];
        return Math.min(arr[left], arr[right]);
    }

    public double log2(double val){
        return Math.log10(val) / Math.log10(2);
    }

    public static void main(String[] args) {
        RMQIndexSparseTable sparseTableRMQ = new RMQIndexSparseTable();
        int[] arr = new int[]{24, 32, 58, 6, 94, 86, 16, 20};
//        int[] arr = new int[]{24, 32, 58, 6};
        sparseTableRMQ.preProcess(arr);
        sparseTableRMQ.printSparseTable();
        System.out.println("----------");
        System.out.println((int)Math.ceil(sparseTableRMQ.log2(1)));
        System.out.println((int)Math.ceil(sparseTableRMQ.log2(2)));
        System.out.println((int)Math.ceil(sparseTableRMQ.log2(3)));
        System.out.println((int)Math.ceil(sparseTableRMQ.log2(4)));
        System.out.println((int)Math.ceil(sparseTableRMQ.log2(5)));
        System.out.println((int)Math.ceil(sparseTableRMQ.log2(6)));
        System.out.println((int)Math.ceil(sparseTableRMQ.log2(7)));
        System.out.println((int)Math.ceil(sparseTableRMQ.log2(8)));
        System.out.println("----------");
        System.out.println(sparseTableRMQ.query(arr,1,7));
        System.out.println(sparseTableRMQ.query(arr,2,7));
        System.out.println(sparseTableRMQ.query(arr,3,4));
        System.out.println(sparseTableRMQ.query(arr,0,7));
        System.out.println(sparseTableRMQ.query(arr,6,7));
        System.out.println(sparseTableRMQ.query(arr,5,7));
        System.out.println(sparseTableRMQ.query(arr,1,4));
        System.out.println(sparseTableRMQ.query(arr,0,5));
        System.out.println(sparseTableRMQ.query(arr,0,2));
        System.out.println(sparseTableRMQ.query(arr,0,1));
        System.out.println(sparseTableRMQ.query(arr,4,4));

    }
}


/*public class RMQSparseTable implements RMQStructure{
    int[][] sparseTbl;
    @Override
    public void preProcess(int[] arr) {
        int blkSize = arr.length;
        int n = (int) Math.ceil(log2(blkSize)) + 1;
        sparseTbl = new int[blkSize][n];

        for (int i = 0; i < blkSize; i++) {
            sparseTbl[i][0] = arr[i];
        }

        int j = 0,k = 0;
        while(Math.pow(2, j) <= blkSize) {
            while(k < (Math.pow(2, j) - 1)) {
                Integer min = Math.min(sparseTbl[k][j-1],sparseTbl[k + (int)Math.pow(2, j-1)][j - 1]);
                sparseTbl[k][j] = min;
                k++;
            }
            j++;
        }
    }

    private void printSparseTable(){
        for (int i = 0; i < sparseTbl.length;  i++){
            for (int j = 0; j < sparseTbl[0].length; j++){
                System.out.print(sparseTbl[i][j] + " ");
            }
            System.out.println();
        }
    }

    @Override
    public int query(int[] arr, int i, int j) {
        int rnd = (int) Math.floor(log2(j - i + 1));
        int next = sparseTbl[j - (int) Math.pow(2, rnd) + 1][rnd];
        int prev = sparseTbl[i][rnd];
        return Math.min(prev, next);
    }

    public double log2(double val){
        return Math.log10(val) / Math.log10(2);
    }

    public static void main(String[] args) {
        RMQSparseTable sparseTableRMQ = new RMQSparseTable();
//        int[] arr = new int[]{34, 32, 58, 6, 94, 86, 16, 20};
        int[] arr = new int[]{44, 42, 57, 8, 91, 83, 18, 27};
        sparseTableRMQ.preProcess(arr);
        sparseTableRMQ.printSparseTable();
    }
}
*/
package dxp190051;

import java.util.Arrays;

public class RMQBlock implements RMQStructure{
    int[] arrBlock;
    int size;
    @Override
    public void preProcess(int[] arr) {
        size = (int)Math.ceil(Math.sqrt(arr.length));
        arrBlock = new int[size];
        Arrays.fill(arrBlock, Integer.MAX_VALUE);

        int i = 0;
        while (i < arr.length) {
            int n = i/size;
            arrBlock[n] = Math.min(arr[i], arrBlock[n]);
            i++;
        }
    }

    private void printBlockArray(){
        for(int i = 0; i < arrBlock.length; i++) {
            System.out.print(arrBlock[i] + " ");
        }
    }

    @Override
    public int query(int[] arr, int left, int right) {
        int blkLeft = left/size;
        int blkRight = right/size;
        int min = Integer.MAX_VALUE;

        if(blkLeft == blkRight){
            int i = 0;
            while (i <= right) {
                min = Math.min(min, arr[i]);
                i++;
            }
            return min;
        }

        //get blocks min except left and right blocks
        int i = blkLeft + 1;
        while (i <= blkRight - 1) {
            min = Math.min(min, arrBlock[i]);
            i++;
        }

        //get left block min
        i = left;
        while (i <= (blkLeft + 1) * size) {
            min = Math.min(min,arr[i]);
            i++;
        }

        //get right block min
        i = blkRight * size;
        while (i <= right) {
            min = Math.min(min,arr[i]);
            i++;
        }

        return min;
    }

    public double log2(double val){
        return Math.log10(val) / Math.log10(2);
    }

    public static void main(String[] args) {
        RMQBlock rmqBlock = new RMQBlock();
//        int[] arr = new int[]{24, 32, 58, 6, 94, 86, 16, 20};
        int[] arr = new int[]{44, 42, 57, 8, 91, 83, 18, 27};
        rmqBlock.preProcess(arr);
        rmqBlock.printBlockArray();
        System.out.println("----------");
        System.out.println((int)Math.ceil(rmqBlock.log2(1)));
        System.out.println((int)Math.ceil(rmqBlock.log2(2)));
        System.out.println((int)Math.ceil(rmqBlock.log2(3)));
        System.out.println((int)Math.ceil(rmqBlock.log2(4)));
        System.out.println((int)Math.ceil(rmqBlock.log2(5)));
        System.out.println((int)Math.ceil(rmqBlock.log2(6)));
        System.out.println((int)Math.ceil(rmqBlock.log2(7)));
        System.out.println((int)Math.ceil(rmqBlock.log2(8)));
        System.out.println("----------");
        System.out.println(rmqBlock.query(arr,1,5));
        System.out.println(rmqBlock.query(arr,2,7));
        System.out.println(rmqBlock.query(arr,3,4));
        System.out.println(rmqBlock.query(arr,0,7));
        System.out.println(rmqBlock.query(arr,6,7));
        System.out.println(rmqBlock.query(arr,5,7));
        System.out.println(rmqBlock.query(arr,1,4));
        System.out.println(rmqBlock.query(arr,0,5));
        System.out.println(rmqBlock.query(arr,0,2));
        System.out.println(rmqBlock.query(arr,0,1));
        System.out.println(rmqBlock.query(arr,4,4));
    }
}

package dxp190051;

public class RMQHybridOne implements RMQStructure{
    @Override
    public void preProcess(int[] arr) {
        RMQBlock blk = new RMQBlock();
        blk.preProcess(arr);
        int[] blockMin = blk.arrBlock;
        RMQSparseTable rmwSparseTbl = new RMQSparseTable();
        rmwSparseTbl.preProcess(blockMin);
    }

    @Override
    public int query(int[] arr, int i, int j) {
        return 0;
    }
}

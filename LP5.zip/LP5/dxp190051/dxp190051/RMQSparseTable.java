package dxp190051;

public class RMQSparseTable implements RMQStructure{
    int[][] sparseTbl;
    @Override
    public void preProcess(int[] arr) {
        int size = arr.length;
        int n = (int) Math.ceil(log2(size)) + 1;
        sparseTbl = new int[size][n];

        for (int i = 0; i < size; i++) {
            sparseTbl[i][0] = arr[i];
        }

        int j = 0,k = 0;
        while(Math.pow(2, j) <= size) {
            while(k < (Math.pow(2, j) - 1)) {
                Integer min = Math.min(sparseTbl[k][j-1],sparseTbl[k + (int)Math.pow(2, j-1)][j - 1]);
                sparseTbl[k][j] = min;
                k++;
            }
            j++;
        }
    }

    private void printSparseTable(){
        for (int i = 0; i < sparseTbl.length;  i++){
            for (int j = 0; j < sparseTbl[0].length; j++){
                System.out.print(sparseTbl[i][j] + " ");
            }
            System.out.println();
        }
    }

    @Override
    public int query(int[] arr, int i, int j) {
        int rnd = (int) Math.floor(log2(j - i + 1));
        int next = sparseTbl[j - (int) Math.pow(2, rnd) + 1][rnd];
        int prev = sparseTbl[i][rnd];
        return Math.min(prev, next);
    }

    public double log2(double val){
        return Math.log10(val) / Math.log10(2);
    }

    public static void main(String[] args) {
        RMQSparseTable sparseTableRMQ = new RMQSparseTable();
//        int[] arr = new int[]{34, 32, 58, 6, 94, 86, 16, 20};
        int[] arr = new int[]{44, 42, 57, 8, 91, 83, 18, 27};
        sparseTableRMQ.preProcess(arr);
        sparseTableRMQ.printSparseTable();
    }
}
